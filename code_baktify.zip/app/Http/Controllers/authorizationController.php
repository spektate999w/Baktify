<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;

class authorizationController extends Controller
{
    public function signIn(Request $req) {
        $isValid = [
            "email" => $req->mail,
            "password" => $req->pw
        ];

        if(Auth::attempt($isValid, true)==true) {
            Cookie::queue(
                "rememberMe",
                Auth::user()->email,
                15780000
            );
            return redirect()->route("showHome");
        }else {
            return redirect()->back();
        }
    }

    public function signOut() {
        Auth::logout();
        return redirect()->route("showHome");
    }

}
