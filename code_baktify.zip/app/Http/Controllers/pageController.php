<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Category;
use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class pageController extends Controller
{
    function showAbout (){
        return view('about');
    }

    function showSignUp () {
        return view('signUp');
    }

    function showSignIn () {
        return view("signIn");
    }

    function showProfile () {
        return view("profile");
    }

    function showUpdateProfile (){
        return view("updateProfile");
    }

    function showProduct () {
        $prds = Product::paginate(12);
        return view("product", compact("prds"));
    }

    function showInsertProduct () {
        $cat = Category::all();
        return view("insertProduct", compact("cat"));
    }

    function showAddCategory () {
        $cat = Category::all();
        return view("addCategory", compact("cat"));
    }

    function searching (Request $req) {
        $prds = Product::where("name", "LIKE", "%$req->sch%")->paginate(12)->withQueryString();
        return view("product", compact("prds"));
    }

    function showUpdateProduct (Request $req) {
        $temp = Product::find($req->passingId);
        return view("updateProduct", compact("temp"));
    }

    function showDetailProduct (Request $req) {
        $temp = Product::find($req->det);
        return view('productDetail', compact("temp"));
    }

    function showCart (){
        $temp = Cart::where("id_user","LIKE", Auth::user()->id)->get();
        $grandTotal = 0;
        foreach($temp as $tempOne) {
            $grandTotal += ($tempOne->quantity * $tempOne->callProduct->price);
        }
        return view("cart", compact("temp", "grandTotal"));
    }

    function readyCart (){
        $temp = Cart::where("id_user","LIKE", Auth::user()->id)->get();
        $grandTotal = 0;
        foreach($temp as $tempOne) {
            $grandTotal += ($tempOne->quantity * $tempOne->callProduct->price);
        }

        $requirement = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $generateCode = null;
        for($rand=0; $rand<=5; $rand++){
            $generateCode = $generateCode.$requirement[mt_rand(0, strlen($requirement)-1)];
        }

        return view("cartCheckOut", compact("temp", "grandTotal", "generateCode"));
    }

    function showTransaction (){
        $tempFour = Transaction::where("id_user","LIKE", Auth::user()->id)->get();
        $temp = Transaction::where("id_user","LIKE", Auth::user()->id)->get();
        $grandTotal = 0;
        foreach($temp as $tempOne) {
            $grandTotal = $grandTotal + ($tempOne->quantity * $tempOne->callProductTr->price);
        }
        return view("transaction", compact("tempFour", "grandTotal"));
    }
}
