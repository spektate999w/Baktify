<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class adminController extends Controller
{
    public function addCategory (Request $req) {
        $req->validate([
            "name" => "required|alpha|unique:categories,name"
        ]);

        $temp = new Category();
        $temp->name = $req->name;
        $temp->save();

        return redirect()->route('showHome');
    }

    public function insertProduct(Request $req) {
        $req->validate([
            "prn" => "required|min:5",
            "dec" => "required|min:15|max:500",
            "prc" => "required|numeric|min:1000|max:10000000",
            "prq"=> "required|numeric|min:1|max:10000",
            "img" => "required|mimes:jpg,jpeg,png",
            "ctg" => "required"
        ]);

        $tempOne = $req->file("img")->getClientOriginalExtension();
        $tempTwo = $req->file("img")->getClientOriginalName();
        $res = $tempTwo.time().".".$tempOne;
        $req->file("img")->storeAs("public/stockImg",$res);
        $tempThree = new Product();
        $tempThree->name = $req->prn;
        $tempThree->description = $req->dec;
        $tempThree->price = $req->prc;
        $tempThree->stock = $req->prq;
        $tempThree->image = $res;
        $tempThree->id_category = $req->ctg;
        $tempThree->save();

        return redirect()->route("showProduct");
    }

    public function deleteProduct (Request $req) {
        Product::find($req->del)->delete();
        return redirect()->route("showProduct");
    }

    public function updateProduct (Request $req) {
        // dd($req->id);

        $req->validate([
            "dec" => "required|min:15|max:500",
            "prc" => "required|numeric|min:1000|max:10000000",
            "prq"=> "required|numeric|min:1|max:10000",
            "img" => "required|mimes:jpg,jpeg,png",
        ]);

        $tempOne = $req->file("img")->getClientOriginalExtension();
        $tempTwo = $req->file("img")->getClientOriginalName();
        $res = $tempTwo.time().".".$tempOne;
        $req->file("img")->storeAs("public/stockImg",$res);
        $updated = new Product();
        $updated->exists = true;
        $updated->id = $req->id;
        $updated->description = $req->dec;
        $updated->price = $req->prc;
        $updated->stock = $req->prq;
        $updated->image = $res;
        $updated->save();

        return redirect()->route("showProduct");
    }

}

