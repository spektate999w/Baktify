

<?php $__env->startSection('webCon'); ?>
<div>
    <h3 class="text-center fw-semibold my-4">Your Profile</h3>
    <div class="d-flex justify-content-center">
        <div class="bg-light shadow rounded p-3 w-75 mb-5">
            <div class="my-3">
                <div>Name</div>
                <input disabled name="name" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->name); ?>">
            </div>
            <div class="my-3">
                <div>Email address</div>
                <input disabled name="mail" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->email); ?>">
            </div>
            <div class="my-3">
                <div>Password</div>
                <input disabled name="pw" class="border-secondary border rounded" type="password" value=<?php echo e(Auth::user()->password); ?>>
            </div>
            <div class="my-3">
                <div>Address</div>
                <textarea disabled name="adr" class="border-secondary border rounded"><?php echo e(Auth::user()->address); ?></textarea>
                <div class="text-secondary">Please write your actual address where you can receive email</div>
            </div>
            <div class="my-3">
                <div>Phone</div>
                <input disabled name="phn" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->phone); ?>">
            </div>
            <div class="d-flex gap-4 justify-content-end">
                <a href="/update-profile">
                    <button class="btn btn-primary p-1">Update</button>
                </a>
                <a href="<?php echo e(route('signingOut')); ?>">
                    <button class="btn btn-danger p-1">Sign Out</button>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/profile.blade.php ENDPATH**/ ?>