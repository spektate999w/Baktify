<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <title>Baktify</title>
</head>
<body style="background-color: rgb(245, 245, 245)">
    <?php if(!Auth::user()): ?>
        <?php echo $__env->make('navbarGuest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php endif; ?>

    <?php if(Auth::user()): ?>
        <?php if(Auth::user()->role == "user"): ?>
            <?php echo $__env->make('navbarMember', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <?php endif; ?>
        <?php if(Auth::user()->role == "admin"): ?>
            <?php echo $__env->make('navbarAdm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <?php endif; ?>
    <?php endif; ?>

    <div class="container">
        <?php echo $__env->yieldContent('webCon'); ?>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Rico\Downloads\TempTry\Baktify-main\resources\views/template.blade.php ENDPATH**/ ?>