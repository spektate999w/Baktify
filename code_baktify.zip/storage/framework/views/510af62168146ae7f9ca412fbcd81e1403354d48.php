
<?php $__env->startSection('webCon'); ?>
    <div class="my-5">
        <div class="d-flex justify-content-center my-3">
            <img src="<?php echo e(asset("storage/stockImg"."/".$temp->image)); ?>" class="rounded" style="width: 200px; heigh:200px;">
        </div>
        <h3><?php echo e($temp->name); ?></h3>
        <div><?php echo e($temp->description); ?></div>
        <div>Stock: <?php echo e($temp->stock); ?></div>
        <div>Category: <?php echo e($temp->cat->name); ?></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/productDetail.blade.php ENDPATH**/ ?>