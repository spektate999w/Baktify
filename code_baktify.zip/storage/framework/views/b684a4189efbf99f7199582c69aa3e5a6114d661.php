
<?php $__env->startSection('webCon'); ?>
    <div>
        <?php if(count($temp) == 0): ?>
            <h3>Your cart is empty</h3>
        <?php else: ?>
            <h3>Your cart</h3>
            <div class="d-flex my-4 fw-semibold p-3 rounded" style="background-color: rgb(199, 199, 199)">
                <div style="width: 25%">Product</div>
                <div style="width: 25%">PRICE</div>
                <div style="width: 20%">QTY</div>
                <div style="width: 20%">SUBTOTAL</div>
            </div>
            <?php $__currentLoopData = $temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-light shadow d-flex align-items-center my-2 rounded p-2 rounded">
                    <div style="width: 25%"><img class="rounded-circle me-2" src="<?php echo e(asset("storage/stockImg"."/".$cart->callProduct->image)); ?>" style="width:25px; height:25px;"><?php echo e($cart->callProduct->name); ?></div>
                    <div style="width: 25%">IDR <?php echo e($cart->callProduct->price); ?></div>
                    <form action="<?php echo e(route("updateQty")); ?>" class="d-flex" style="width: 50%" method="post">
                        <?php echo method_field('patch'); ?>;
                        <?php echo csrf_field(); ?>
                        <div style="width: 38%">
                            <input style="width: 20%" class="rounded" type="text" name="updateQty" value="<?php echo e($cart->quantity); ?>">
                            <input style="display: none" class="rounded" type="text" name="crtId" value="<?php echo e($cart->id); ?>">
                        </div>
                        <div style="width: 20%">IDR <?php echo e($cart->quantity * $cart->callProduct->price); ?></div>
                        <button type="submit" class="btn btn-primary shadow-sm">Update Cart</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-end fw-semibold">IDR <?php echo e($grandTotal); ?></div>
            <a href="<?php echo e(route("readyCart")); ?>"class="btn btn-primary shadow-sm rounded p-1">Checkout</a>
        <?php endif; ?>
    </div>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/cart.blade.php ENDPATH**/ ?>