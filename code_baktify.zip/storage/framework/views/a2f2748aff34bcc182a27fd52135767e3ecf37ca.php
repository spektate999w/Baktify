
<?php $__env->startSection('webCon'); ?>
    <div>
        <div class="d-flex align-items-center justify-content-between">
            <h3>OUR PRODUCTS</h3>
            <form action="<?php echo e(route("searchName")); ?>" method="get" enctype="multipart/form-data" class="d-flex align-items-center gap-2">
                <?php echo csrf_field(); ?>
                <input name="sch" type="search" placeholder="Search Product" class="rounded border border-secondary">
                <button class="p-1 bg-primary rounded text-light text-decoration-none" style="cursor: pointer">Search</button>
                <?php if(Auth::user()): ?>
                    <?php if(Auth::user()->role == "admin"): ?>
                        <a href="/insert-product" class="p-1 bg-primary rounded text-light text-decoration-none" style="cursor: pointer">Insert Product</a>
                    <?php endif; ?>
                <?php endif; ?>
            </form>
        </div>
        <div class="my-5 gap-5" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(20rem, 1fr));">
            <?php $__currentLoopData = $prds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded bg-light shadow text-center p-4" style="width: 25rem">
                <a href="<?php echo e(route("showDetailProduct", ["det" => $product->id])); ?>" class="text-decoration-none text-dark">
                    <img style="width: 80px; height: 80px" src="<?php echo e(asset("storage/stockImg"."/".$product->image)); ?>" alt="" class="rounded">
                    <div class="fw-semibold text-dark"><?php echo e($product->name); ?></div>
                    <div>IDR <?php echo e($product->price); ?></div>
                    <div class="bg-warning rounded-pill p-1 text-dark my-2"><?php echo e($product->cat->name); ?></div>
                    <div class="mt-4">
                        <?php if(!Auth::user() || Auth::user()->role == "user"): ?>
                            <?php if(!Auth::user()): ?>
                                <a href="<?php echo e(route("showSignIn")); ?>" onclick="callLog()" class="btn btn-primary rounded-pill shadow-sm">Add To Cart</a>
                            <?php else: ?>
                            <form action="<?php echo e(route("addCart")); ?>" enctype="multipart/form-data" method="post">
                                <?php echo csrf_field(); ?>
                                <input style="display: none" name="id_product" value="<?php echo e($product->id); ?>">
                                <button class="btn btn-primary rounded-pill shadow-sm">Add To Cart</button>
                            </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="d-flex justify-content-around border-top border-dark pt-3">
                                <a href="<?php echo e(route("showUpdateProduct", ['passingId' => $product->id])); ?>" class="btn btn-primary rounded-pill shadow-sm">Edit Product</a>
                                <form  method="post" action="<?php echo e(route("deleteProduct", ["del" => $product->id])); ?>">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger rounded-pill shadow-sm">Remove Product</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($prds->links()); ?>

    </div>
    <script>
        function callLog(){
            alert("Please sign in to add to cart!")
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rico\Downloads\TempTry\Baktify-main\resources\views/product.blade.php ENDPATH**/ ?>