
<?php $__env->startSection('webCon'); ?>
<div>
    <h3 class="text-center fw-semibold my-4">Sign in to your account</h3>
    <div class="d-flex justify-content-center">
        <div class="w-75 bg-light p-3 rounded shadow my-5">
            <form action=<?php echo e(route("signingIn")); ?> enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>
                <div class="my-3">
                    <div>Email address</div>
                    <input name="mail" class="w-100 border-secondary border rounded" type="text">
                    <div class="text-danger">
                        <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="my-3">
                    <div>Password</div>
                    <input name="pw" class="w-100 border-secondary border rounded" type="password">
                    <div class="text-danger">
                        <?php $__errorArgs = ['pw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="d-flex gap-1">
                    <input type="checkbox">
                    <div>Remember Email</div>
                </div>
                <br>
                <div>
                    <button class="btn btn-primary p-1 w-100 shadow">Sign In</button>
                </div>
                <div class="text-center my-3">or</div>
            </form>
            <div>
                <a href="<?php echo e(route("showSignUp")); ?>">
                    <button class="btn btn-outline-primary p-1 w-100">Register</button>
                </a>
            </div>
        </div>    
    </div>
    <br>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/signIn.blade.php ENDPATH**/ ?>