<nav class="bg-light d-flex justify-content-evenly py-3 shadow align-items-center">
    <a href="/" class="w-25 text-center text-decoration-none text-dark">
        <div>&#127757;</div>
        <div class="fw-semibold fs-5">Baktify</div>
    </a>
    <div class="w-50 text-center">
        <a href="/about" class="mx-3 text-decoration-none text-dark">About us</a>
        <a href="/product" class="mx-3 text-decoration-none text-dark">Products</a>
        <a href="<?php echo e(route("showTransaction")); ?>" class="mx-3 text-decoration-none text-dark">My Transactions</a>
    </div>
    <div class="d-flex w-25 justify-content-center align-items-center gap-5">
        <a href="<?php echo e(route("showCart")); ?>" class="text-decoration-none text-dark fw-semibold">Cart</a>
        <a href="/show-profile" class="text-decoration-none text-dark">
            <div>member</div>
            <div>View Profile</div>
        </a>
            
    </div>
</nav><?php /**PATH C:\JOK\LabProject\resources\views/navbarMember.blade.php ENDPATH**/ ?>