<footer class="w-100 text-center shadow-lg py-4 bg-light">
    © 2021 Baktify.Inc.All rights reserved.
</footer><?php /**PATH C:\Users\Rico\Downloads\TempTry\Baktify-main\resources\views/footer.blade.php ENDPATH**/ ?>