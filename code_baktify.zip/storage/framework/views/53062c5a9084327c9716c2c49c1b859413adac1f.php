
<?php $__env->startSection('webCon'); ?>
    <div>
        <h3 class="my-3">Add new Category</h3>
        <div class="d-flex gap-2">
            <?php if(count($cat) == 0): ?>
                <div>No Category</div>
            <?php else: ?>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn btn-warning">
                        <?php echo e($req->name); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('addCategory')); ?>" enctype="multipart/form-data" method="POST" class="my-5">
            <?php echo csrf_field(); ?>
            <div class="d-flex">
                <div class="w-25">Category Name</div>
                <input class="w-75 rounded" type="text" name="name">
            </div>
            <div class="text-danger">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
            </div>
            <br>
            <button class="btn btn-primary shadow">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/addCategory.blade.php ENDPATH**/ ?>