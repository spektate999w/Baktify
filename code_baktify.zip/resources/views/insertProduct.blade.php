@extends('template')
@section('webCon')
    <form action="{{route("insertProduct")}}" enctype="multipart/form-data" method="POST" class="my-5">
        @csrf
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Image</div>
            <input name="img" class="w-75" type="file">
        </div>
        <div class="text-danger">
            @error('img')
                {{$message}}
            @enderror
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Product Name</div>
            <input name="prn" class="w-75" type="text">
        </div>
        <div class="text-danger">
            @error('prn')
                {{$message}}
            @enderror
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Description</div>
            <input name="dec" class="w-75" type="text">
        </div>
        <div class="text-danger">
            @error('dec')
                {{$message}}
            @enderror
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Price</div>
            <input name="prc" class="w-75" type="number">
        </div>
        <div class="text-danger">
            @error('prc')
                {{$message}}
            @enderror
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Product Quantity</div>
            <input name="prq" class="w-75" type="number">
        </div>
        <div class="text-danger">
            @error('prq')
                {{$message}}
            @enderror
        </div>
        <div class="d-flex py-3 my-3 border-bottom border-dark">
            <div class="w-25">
                Category Name
            </div>
            <div class="w-75">
                @if (count($cat) == 0)
                    <div class="text-danger">Please add the category first!</div>
                @else 
                    <div>
                        <select name="ctg" id="">
                            @foreach ($cat as $req)
                                <option value="{{$req->id}}">{{$req->name}}</option>
                            @endforeach
                        </select>
                        @error('ctg')
                            {{$message}}
                        @enderror
                    </div>
                @endif
            </div>
        </div>
        <div class="d-flex gap-3">
            <div>
                <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Insert</button>
            </div>
            <div>
                <a class="p-1 btn btn-danger" href="/product">Cancel</a>
            </div>
        </div>
    </form>
@endsection