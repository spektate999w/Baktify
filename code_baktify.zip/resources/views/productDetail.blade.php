@extends('template')
@section('webCon')
    <div class="my-5">
        <div class="d-flex justify-content-center my-3">
            <img src="{{asset("storage/stockImg"."/".$temp->image)}}" class="rounded" style="width: 200px; heigh:200px;">
        </div>
        <h3>{{$temp->name}}</h3>
        <div>{{$temp->description}}</div>
        <div>Stock: {{$temp->stock}}</div>
        <div>Category: {{$temp->cat->name}}</div>
    </div>
@endsection