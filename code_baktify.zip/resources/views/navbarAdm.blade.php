<nav class="bg-light d-flex justify-content-evenly py-3 shadow align-items-center">
    <a href="/" class="w-25 text-center text-decoration-none text-dark">
        <div>&#127757;</div>
        <div class="fw-semibold fs-5">Baktify</div>
    </a>
    <div class="w-50 text-center">
        <a href="/about" class="mx-3 text-decoration-none text-dark">About us</a>
        <a href="/product" class="mx-3 text-decoration-none text-dark">Manage Products</a>
        <a href="/add-category" class="mx-3 text-decoration-none text-dark">Add Category</a>
    </div>
    <div class="w-25 text-end">
        <a href="/show-profile" class="text-center text-decoration-none text-dark">
            <div>admin</div>
            <div>View Profile</div>
        </a>
    </div>
</nav>