@extends('template')
@section('webCon')
    <div>
        <h3 class="my-3">Add new Category</h3>
        <div class="d-flex gap-2">
            @if (count($cat) == 0)
                <div>No Category</div>
            @else
                @foreach ($cat as $req)
                    <div class="btn btn-warning">
                        {{$req->name}}
                    </div>
                @endforeach
            @endif
        </div>
        <form action="{{route('addCategory')}}" enctype="multipart/form-data" method="POST" class="my-5">
            @csrf
            <div class="d-flex">
                <div class="w-25">Category Name</div>
                <input class="w-75 rounded" type="text" name="name">
            </div>
            <div class="text-danger">
                @error('name')
                    {{$message}}
                @enderror
                <br>
            </div>
            <br>
            <button class="btn btn-primary shadow">Submit</button>
        </form>
    </div>
@endsection