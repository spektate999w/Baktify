@extends('template')
@section('webCon')    
<div>
    <div class="w-100 text-center my-5">
        "Baktify started form our love for musci and album, 
        we create Baktify to spread the love in our music community,
         we started off from street near Rawa Belong street and now 
         we have the most diverse collection of albums and musics, 
         We won't stop until music spreads all over the world"
    </div>

    <div class="fw-semibold text-center my-5">Conny Blue, CEO Baktify</div>

    <div class="d-flex my-5 border-top border-dark">
        <div class="fw-bold w-50 py-2 text-center">Get in touch</div>
        <div class="w-50 d-flex">
            <div class="w-100">
                <div>
                    <div class="fw-semibold my-2">Sales Inquiry</div>
                    <div>sales@baktify.com</div>
                    <div>+62 1231 1231</div>
                </div>
                <br>
                <div>
                    <div class="fw-semibold my-2">Sales Inquiry</div>
                    <div>sales@baktify.com</div>
                    <div>+62 1231 1231</div>
                </div>
            </div>
            <div class="w-100">
                <div>
                    <div class="fw-semibold my-2">Sales Inquiry</div>
                    <div>sales@baktify.com</div>
                    <div>+62 1231 1231</div>
                </div>
                <br>
                <div>
                    <div class="fw-semibold my-2">Sales Inquiry</div>
                    <div>sales@baktify.com</div>
                    <div>+62 1231 1231</div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="d-flex my-5">
        <div class="fw-bold w-50 py-2 text-center">Location</div>
        <div class="w-50 d-flex">
            <div class="w-100">
                <div>
                    <div class="fw-semibold my-2">Jakarta</div>
                    <div>Jl. Rawa Belong No.420</div>
                    <div>11420</div>
                </div>
                <br>
                <div>
                    <div class="fw-semibold my-2">Jakarta</div>
                    <div>Jl. Rawa Belong No.420</div>
                    <div>11420</div>
                </div>
            </div>
            <div class="w-100">
                <div>
                    <div class="fw-semibold my-2">Jakarta</div>
                    <div>Jl. Rawa Belong No.420</div>
                    <div>11420</div>
                </div>
                <br>
                <div>
                    <div class="fw-semibold my-2">Jakarta</div>
                    <div>Jl. Rawa Belong No.420</div>
                    <div>11420</div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection