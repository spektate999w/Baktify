@extends('template')
@section('webCon')
<div>
    <h3 class="text-center fw-semibold my-4">Update Profile</h3>
    <div class="d-flex justify-content-center">
    <form action={{ route("updateProfile") }} enctype="multipart/form-data" method="post" class="bg-light shadow rounded p-3 w-75 mb-5">
        @method('patch')
        @csrf
        <div class="my-3">
            <div>Name</div>
            <input name="name" class="border-secondary border rounded" type="text" value="{{Auth::user()->name}}">
            <div class="text-danger">
                @error('name')
                    {{$message}}
                @enderror
            </div>
        </div>
        <div class="my-3">
            <div>Email address</div>
            <input disabled name="mail" class="border-secondary border rounded" type="text" value="{{Auth::user()->email}}">
            <div class="text-danger">
                @error('mail')
                    {{$message}}
                @enderror
            </div>
        </div>
        <div class="d-flex gap-5 my-2">
            <div>
                <div>Password</div>
                <input name="pw" class="border-secondary border rounded" type="password" value="{{Auth::user()->password}}">
            </div>
            <div>
                <div>Confirm Password</div>
                <input name="confPw" class="border-secondary border rounded" type="password">
            </div>
        </div>
        <div class="text-danger">
            @error('pw')
                {{$message}}
            @enderror
        </div>
        <div class="my-3">
            <div>Address</div>
            <textarea name="adr" class="border-secondary border rounded" name="" id="">{{Auth::user()->address}}</textarea>
            <div class="text-danger">
                @error('adr')
                    {{$message}}
                @enderror
            </div>
            <div class="text-secondary">Please write your actual address where you can receive email</div>
        </div>
        <div class="my-3">
            <div>Phone</div>
            <input name="phn" class="border-secondary border rounded" type="text" value="{{Auth::user()->phone}}">
            <div class="text-danger">
                @error('phn')
                    {{$message}}
                @enderror
            </div>
        </div>
        <div class="d-flex justify-content-end gap-3">
            <div>
                <a class="p-1 btn btn-danger" href="/show-profile">Cancel</a>
            </div>
            <div>
                <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Save</button>
            </div>
        </div>
        <input type="text" style="display: none" value={{Auth::user()->id}} name="id">
    </form>
    </div>
</div>
@endsection