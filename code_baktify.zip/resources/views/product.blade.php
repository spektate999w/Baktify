@extends('template')
@section('webCon')
    <div>
        <div class="d-flex align-items-center justify-content-between">
            <h3>OUR PRODUCTS</h3>
            <form action="{{route("searchName")}}" method="get" enctype="multipart/form-data" class="d-flex align-items-center gap-2">
                @csrf
                <input name="sch" type="search" placeholder="Search Product" class="rounded border border-secondary">
                <button class="p-1 bg-primary rounded text-light text-decoration-none" style="cursor: pointer">Search</button>
                @if (Auth::user())
                    @if (Auth::user()->role == "admin")
                        <a href="/insert-product" class="p-1 bg-primary rounded text-light text-decoration-none" style="cursor: pointer">Insert Product</a>
                    @endif
                @endif
            </form>
        </div>
        <div class="my-5 gap-5" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(20rem, 1fr));">
            @foreach ($prds as $product)
            <div class="rounded bg-light shadow text-center p-4" style="width: 25rem">
                <a href="{{route("showDetailProduct", ["det" => $product->id])}}" class="text-decoration-none text-dark">
                    <img style="width: 80px; height: 80px" src="{{asset("storage/stockImg"."/".$product->image)}}" alt="" class="rounded">
                    <div class="fw-semibold text-dark">{{$product->name}}</div>
                    <div>IDR {{$product->price}}</div>
                    <div class="bg-warning rounded-pill p-1 text-dark my-2">{{$product->cat->name}}</div>
                    <div class="mt-4">
                        @if (!Auth::user() || Auth::user()->role == "user")
                            @if (!Auth::user())
                                <a href="{{route("showSignIn")}}" onclick="callLog()" class="btn btn-primary rounded-pill shadow-sm">Add To Cart</a>
                            @else
                            <form action="{{route("addCart")}}" enctype="multipart/form-data" method="post">
                                @csrf
                                <input style="display: none" name="id_product" value="{{$product->id}}">
                                <button class="btn btn-primary rounded-pill shadow-sm">Add To Cart</button>
                            </form>
                            @endif
                        @else
                            <div class="d-flex justify-content-around border-top border-dark pt-3">
                                <a href="{{route("showUpdateProduct", ['passingId' => $product->id])}}" class="btn btn-primary rounded-pill shadow-sm">Edit Product</a>
                                <form  method="post" action="{{route("deleteProduct", ["del" => $product->id])}}">
                                    @method('delete')
                                    @csrf
                                    <button class="btn btn-danger rounded-pill shadow-sm">Remove Product</button>
                                </form>
                            </div>
                        @endif
                    </div>
                </a>
            </div>
            @endforeach
        </div>
        {{$prds->links()}}
    </div>
    <script>
        function callLog(){
            alert("Please sign in to add to cart!")
        }
    </script>
@endsection