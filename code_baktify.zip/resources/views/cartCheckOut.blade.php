@extends('template')
@section('webCon')
    <div>
        @if (count($temp) == 0)
            <h3>Your cart is empty</h3>
        @else
            <h3>Your cart</h3>
            <div class="d-flex my-4 fw-semibold p-3 rounded" style="background-color: rgb(199, 199, 199)">
                <div style="width: 25%">Product</div>
                <div style="width: 25%">PRICE</div>
                <div style="width: 20%">QTY</div>
                <div style="width: 20%">SUBTOTAL</div>
            </div>
            @foreach ($temp as $cart)
                <div class="bg-light shadow d-flex align-items-center my-2 rounded p-2 rounded">
                    <div style="width: 25%"><img class="rounded-circle me-2" src="{{asset("storage/stockImg"."/".$cart->callProduct->image)}}" style="width:25px; height:25px;">{{$cart->callProduct->name}}</div>
                    <div style="width: 25%">IDR {{$cart->callProduct->price}}</div>
                    <div style="width: 20%">
                        <div class="w-50 border border-dark rounded p-1">
                            {{$cart->quantity}}
                        </div>
                    </div>
                    <div style="width: 20%">IDR {{$cart->quantity * $cart->callProduct->price}}</div>
                </div>
            @endforeach
            <div class="text-end fw-semibold">IDR {{$grandTotal}}</div>
        @endif
        <div>Ship to: {{$cart->callMember->address}}</div>
        <br>
        <div class="w-100 d-flex justify-content-end">
            <div>
                <div>Please enter the following code to checkout: {{$generateCode}}</div>
                <form action="{{route("checkOut")}}" enctype="multipart/form-data" method="post" class="w-100">
                    @csrf
                    <div class="w-50 my-2">
                        <input type="text" name="inputCode" class="rounded">
                    </div>
                    <input style="display: none" name="genCode" value="{{$generateCode}}">
                    <div class="text-danger">
                        @error('inputCode')
                            Passcode does not match
                        @enderror
                    </div>
                    <button class=" w-50 btn btn-primary">Confirm</button>
                </form>
            </div>
        </div>
    </div>
    <br>
@endsection