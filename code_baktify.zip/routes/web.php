<?php

use App\Http\Controllers\adminController;
use App\Http\Controllers\authorizationController;
use App\Http\Controllers\GuestController;
use App\Http\Controllers\memberController;
use App\Http\Controllers\pageController;
use App\Http\Middleware\Guest;
use App\Http\Middleware\Logged;
use App\Http\Middleware\RoleAdmin;
use App\Http\Middleware\RoleMember;
use App\Models\Product;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/", function () {
    $temp = Product::all();
    return view("home", compact("temp"));
})->name("showHome");

//go about
Route::get("/about", [pageController::class, "showAbout"]);

//go sign up
Route::get("/sign-up", [pageController::class, "showSignUp"])->name("showSignUp")->middleware([Logged::class]);
//sign up
Route::post("/sign-up-post", [memberController::class, "signUp"])->name("signingUp");

//go sign in
Route::get("/sign-in", [pageController::class, "showSignIn"])->name("showSignIn")->middleware([Logged::class]);
//sign in
Route::post("/sign-in-post", [authorizationController::class, "signIn"])->name("signingIn");
Route::get("/sign-out", [authorizationController::class, "signOut"])->name("signingOut");

//go profile
Route::get("/show-profile", [pageController::class, "showProfile"])->name("showProfile")->middleware([Guest::class]);
//go update profile
Route::get("/update-profile", [pageController::class, "showUpdateProfile"])->name("showUpdateProfile")->middleware([Guest::class]);
Route::patch("/update-profile-post", [memberController::class, "updateProfile"])->name("updateProfile");

//go produc
Route::get("/product", [pageController::class, "showProduct"])->name("showProduct");

//insert product
Route::get("/insert-product", [pageController::class, "showInsertProduct"])->middleware([RoleAdmin::class]);
Route::get("/add-category", [pageController::class, "showAddCategory"])->middleware([RoleAdmin::class]);
Route::post("/add-category-db", [adminController::class, "addCategory"])->name("addCategory");

//inserted product
Route::post("/insert-product-post", [adminController::class, "insertProduct"])->middleware([RoleAdmin::class])->name("insertProduct");

//Search
Route::get("/search", [pageController::class, "searching"])->name("searchName");

//delte product
Route::delete("/delete-post/{del}", [adminController::class, "deleteProduct"])->name("deleteProduct");

//go update product
Route::get("/update-product/{passingId}", [pageController::class, "showUpdateProduct"])->name("showUpdateProduct")->middleware([RoleAdmin::class]);
//update post
Route::patch("/update-product-post", [adminController::class, "updateProduct"])->name("updateProduct");

//go detail
Route::get("/show-detail-product/{det}", [pageController::class, "showDetailProduct"])->name("showDetailProduct");

//go-cart
Route::get("/cart", [pageController::class, "showCart"])->name("showCart")->middleware([RoleMember::class]);
//cart post
Route::post("/cart-post", [memberController::class, "addCart"])->name("addCart");

//update qty
Route::patch("/updateQty-post", [memberController::class, "updateQty"])->name("updateQty");

//ready check out
Route::get("/cart-ready", [pageController::class, "readyCart"])->name("readyCart")->middleware([RoleMember::class]);

//chekcout post
Route::post("/check-out-post", [memberController::class, "checkOut"])->name("checkOut");

//go transaction
Route::get("/transact", [pageController::class, "showTransaction"])->name("showTransaction")->middleware([RoleMember::class]);