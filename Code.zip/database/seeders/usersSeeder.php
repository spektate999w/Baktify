<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class usersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            "id" => "1",
            "name" => "adminJoe",
            "email" => "adminJoe@gmail.com",
            "password" => Hash::make("adminJoe"),
            "address" => "Jl. Rawa belong",
            "phone" => "+62 7878 7878",
            "role" => "admin"
        ]);
    }
}
