@extends('template')
@section('webCon')
    <div>
        @if (count($temp) == 0)
            <h3>Your cart is empty</h3>
        @else
            <h3>Your cart</h3>
            <div class="d-flex my-4 fw-semibold p-3 rounded" style="background-color: rgb(199, 199, 199)">
                <div style="width: 25%">Product</div>
                <div style="width: 25%">PRICE</div>
                <div style="width: 20%">QTY</div>
                <div style="width: 20%">SUBTOTAL</div>
            </div>
            @foreach ($temp as $cart)
                <div class="bg-light shadow d-flex align-items-center my-2 rounded p-2 rounded">
                    <div style="width: 25%"><img class="rounded-circle me-2" src="{{asset("storage/stockImg"."/".$cart->callProduct->image)}}" style="width:25px; height:25px;">{{$cart->callProduct->name}}</div>
                    <div style="width: 25%">IDR {{$cart->callProduct->price}}</div>
                    <form action="{{route("updateQty")}}" class="d-flex" style="width: 50%" method="post">
                        @method('patch');
                        @csrf
                        <div style="width: 38%">
                            <input style="width: 20%" class="rounded" type="text" name="updateQty" value="{{$cart->quantity}}">
                            <input style="display: none" class="rounded" type="text" name="crtId" value="{{$cart->id}}">
                        </div>
                        <div style="width: 20%">IDR {{$cart->quantity * $cart->callProduct->price}}</div>
                        <button type="submit" class="btn btn-primary shadow-sm">Update Cart</button>
                    </form>
                </div>
            @endforeach
            <div class="text-end fw-semibold">IDR {{$grandTotal}}</div>
            <a href="{{route("readyCart")}}"class="btn btn-primary shadow-sm rounded p-1">Checkout</a>
        @endif
    </div>
    <br>
@endsection