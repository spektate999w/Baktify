@extends('template')
@section('webCon')
<div>
    @if (count($tempFour) == 0)
        <h3>Your transaction is empty</h3>
    @else
        <h3>Your transactions</h3>
        <div class="d-flex my-4 fw-semibold p-3 rounded" style="background-color: rgb(199, 199, 199)">
            <div style="width: 25%">Product</div>
            <div style="width: 25%">PRICE</div>
            <div style="width: 20%">QTY</div>
            <div style="width: 20%">SUBTOTAL</div>
        </div>
        @foreach ($tempFour as $tr)
            <div class="bg-light shadow d-flex align-items-center my-2 rounded p-2 rounded">
                <div style="width: 25%"><img class="rounded-circle me-2" src="{{asset("storage/stockImg"."/".$tr->callProductTr->image)}}" style="width:25px; height:25px;">{{$tr->callProductTr->name}}</div>
                <div style="width: 25%">IDR {{$tr->callProductTr->price}}</div>
                <div style="width: 20%">
                    <div class="w-50 border border-dark rounded p-1">
                        {{$tr->quantity}}
                    </div>
                </div>
                <div style="width: 20%">IDR {{$tr->quantity * $tr->callProductTr->price}}</div>
            </div>
        @endforeach
        <div class="text-end fw-semibold">IDR {{$grandTotal}}</div>
    @endif
    <br>
</div>
<br>
@endsection