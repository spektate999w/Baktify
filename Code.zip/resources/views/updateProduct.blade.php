@extends('template')
@section('webCon')
    <div>
        <h3 class="fw-semibold my-3">{{$temp->name}}</h3>
        <div class="d-flex justify-content-center my-3">
            <img src="{{asset("storage/stockImg"."/".$temp->image)}}" class="rounded" style="width: 200px; heigh:200px;">
        </div>

        <form action={{route("updateProduct")}} enctype="multipart/form-data" method="post" class="bg-light shadow rounded p-3 w-75 mb-5">
            @method('patch')
            @csrf
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Image</div>
                <input name="img" class="w-75" type="file">
            </div>
            <div class="text-danger">
                @error('img')
                    {{$message}}
                @enderror
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Description</div>
                <input name="dec" class="w-75" type="text" value="{{$temp->description}}">
            </div>
            <div class="text-danger">
                @error('dec')
                    {{$message}}
                @enderror
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Price</div>
                <input name="prc" class="w-75" type="number" value="{{$temp->price}}">
            </div>
            <div class="text-danger">
                @error('prc')
                    {{$message}}
                @enderror
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Product Quantity</div>
                <input name="prq" class="w-75" type="number" value="{{$temp->stock}}">
            </div>
            <div class="text-danger">
                @error('prq')
                    {{$message}}
                @enderror
            </div>
            <div class="d-flex gap-3">
                <div>
                    <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Update</button>
                </div>
                <div>
                    <a class="p-1 btn btn-danger" href="/product">Cancel</a>
                </div>
            </div>
            <input style="display: none" type="text" name="id" value="{{$temp->id}}">
        </form>

    </div>
@endsection