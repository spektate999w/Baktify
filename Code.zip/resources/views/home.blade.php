@extends('template')
@section('webCon')
    <div class="text-dark">
        <div class="w-100 d-flex justify-content-center my-4">
            <h4 class="text-center w-25 fw-bold">Level Up Your Music Collection</h4>
        </div>
        <div class="w-100 d-flex justify-content-center">
            {{-- looping --}}

                <div class="my-5 gap-5 w-100" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(15rem, 1fr));">
                    @foreach ($temp as $showImg)
                    <div class="" style="width: 8rem">
                        <img style="width: 150px; height: 150px" src="{{asset("storage/stockImg"."/".$showImg->image)}}" alt="" class="rounded">
                    </div>
                    @endforeach
                </div>
        </div>

        <div class="border-top border-dark w-100 text-center">
            <div class="fs-4 fw-semibold">One-stop store for all of you musical enthusiasm need</div>
            <div>We provide wide variety of music genere and album</div>
        </div>

        <div class="d-flex justify-content-end align-items-center my-5">
            <div class="text-end w-75 me-5">we are proud to offer fast and professional delivery services with all major payment mehods available through our onlin eshop. additionally, if you require some flexibility regarding payment, we provide finance options so you can pay in instalments</div>
            <div class="fs-1 bg-primary w-25 p-4 rounded text-center">&#127980;</div>
        </div>
        <br>
        <div class="d-flex align-items-center my-5">
            <div class="fs-1 bg-primary w-25 p-4 rounded text-center">&#128204;</div>
            <div class="w-75 ms-5">Through the lare purchasing volumes, DV and Music Store are able to source container directly from manufacturers worldwwide allowing us to offer a large range of products at sensationally low prices.</div>
        </div>
    </div>
@endsection