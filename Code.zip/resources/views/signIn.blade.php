@extends('template')
@section('webCon')
<div>
    <h3 class="text-center fw-semibold my-4">Sign in to your account</h3>
    <div class="d-flex justify-content-center">
        <div class="w-75 bg-light p-3 rounded shadow my-5">
            <form action={{route("signingIn")}} enctype="multipart/form-data" method="POST">
                @csrf
                <div class="my-3">
                    <div>Email address</div>
                    <input name="mail" class="w-100 border-secondary border rounded" type="text">
                    <div class="text-danger">
                        @error('mail')
                            {{$message}}
                        @enderror
                    </div>
                </div>
                <div class="my-3">
                    <div>Password</div>
                    <input name="pw" class="w-100 border-secondary border rounded" type="password">
                    <div class="text-danger">
                        @error('pw')
                            {{$message}}
                        @enderror
                    </div>
                </div>
                <div class="d-flex gap-1">
                    <input type="checkbox">
                    <div>Remember Email</div>
                </div>
                <br>
                <div>
                    <button class="btn btn-primary p-1 w-100 shadow">Sign In</button>
                </div>
                <div class="text-center my-3">or</div>
            </form>
            <div>
                <a href="{{route("showSignUp")}}">
                    <button class="btn btn-outline-primary p-1 w-100">Register</button>
                </a>
            </div>
        </div>    
    </div>
    <br>
</div>
@endsection