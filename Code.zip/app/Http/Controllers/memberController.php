<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class memberController extends Controller
{
    public function signUp(Request $req){
        $req->validate([
            "name" => "required|max:255",
            "mail" => "required|email|unique:users,email",
            "pw" => "required|min:8|same:confPw",
            "confPw" => "required|min:8",
            "adr" => "required|min:15",
            "phn" => "required|min:11|numeric"
        ]);

        $temp = new User();
        $temp->name = $req->name;
        $temp->email = $req->mail;
        $temp->password = Hash::make($req->pw);
        $temp->address = $req->adr;
        $temp->phone = $req->phn;
        $temp->role = $req->role;
        $temp->save();

        return redirect()->route('showSignIn');
    }

    public function updateProfile(Request $req) {
        $req->validate([
            "name" => "required|max:255",
            "pw" => "required|min:8|same:confPw",
            "confPw" => "required|min:8",
            "adr" => "required|min:15",
            "phn" => "required|numeric|min:11"
        ]);

        $updated = new User();
        $updated->exists = true;
        $updated->id = $req->id;
        $updated->name = $req->name;
        $updated->password = Hash::make($req->pw);
        $updated->address = $req->adr;
        $updated->phone = $req->phn;
        $updated->save();

        return redirect()->route("showHome");
    }

    public function addCart (Request $req){
        $tempOne = new Cart();
        $tempOne->id_user = Auth::user()->id;
        $tempOne->id_product = $req->id_product;
        $tempOne->quantity = 1;
        $tempOne->save();
        return redirect()->back();
    }

    public function updateQty (Request $req){
        $updated = new Cart();
        $updated->exists = true;
        $updated->id = $req->crtId;
        $updated->quantity = $req->updateQty;
        $updated->save();
        $temp = Cart::where("id_user","LIKE", Auth::user()->id)->get();
        $grandTotal = 0;
        foreach($temp as $tempOne) {
            $grandTotal = $grandTotal + ($tempOne->quantity * $tempOne->callProduct->price);
        }
        return view("cart", compact("temp", "grandTotal"));
    }

    public function checkOut (Request $req){
        $req->validate([
            "inputCode" => "required|same:genCode"
        ]);
        
        $temp = Cart::where("id_user","LIKE", Auth::user()->id)->get();

        foreach($temp as $tempOne){

            $stockAvail = Product::find($tempOne->id_product);
            $available = $stockAvail->stock;

            if($available > $tempOne->quantity){
                // when stock ready
                $tempTwo = new Transaction();
                $tempTwo->id_user = Auth::user()->id;
                $tempTwo->id_product = $tempOne->id_product;
                $tempTwo->quantity = $tempOne->quantity;
                $tempTwo->save();
    
                $tempThree = new Product();
                $tempThree->exists = true;
                $tempThree->id = $tempOne->id_product;
                $tempThree->stock = ($tempOne->callProduct->stock - $tempOne->quantity);
                $tempThree->save();
                
                Cart::find($tempOne->id)->delete();
            }
        }
        return redirect()->route("showTransaction");
    }
}
