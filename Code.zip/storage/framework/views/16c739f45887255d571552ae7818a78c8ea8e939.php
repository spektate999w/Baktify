
<?php $__env->startSection('webCon'); ?>
    <div>
        <?php if(count($temp) == 0): ?>
            <h3>Your cart is empty</h3>
        <?php else: ?>
            <h3>Your cart</h3>
            <div class="d-flex my-4 fw-semibold p-3 rounded" style="background-color: rgb(199, 199, 199)">
                <div style="width: 25%">Product</div>
                <div style="width: 25%">PRICE</div>
                <div style="width: 20%">QTY</div>
                <div style="width: 20%">SUBTOTAL</div>
            </div>
            <?php $__currentLoopData = $temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-light shadow d-flex align-items-center my-2 rounded p-2 rounded">
                    <div style="width: 25%"><img class="rounded-circle me-2" src="<?php echo e(asset("storage/stockImg"."/".$cart->callProduct->image)); ?>" style="width:25px; height:25px;"><?php echo e($cart->callProduct->name); ?></div>
                    <div style="width: 25%">IDR <?php echo e($cart->callProduct->price); ?></div>
                    <div style="width: 20%">
                        <div class="w-50 border border-dark rounded p-1">
                            <?php echo e($cart->quantity); ?>

                        </div>
                    </div>
                    <div style="width: 20%">IDR <?php echo e($cart->quantity * $cart->callProduct->price); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-end fw-semibold">IDR <?php echo e($grandTotal); ?></div>
        <?php endif; ?>
        <div>Ship to: <?php echo e($cart->callMember->address); ?></div>
        <br>
        <div class="w-100 d-flex justify-content-end">
            <div>
                <div>Please enter the following code to checkout: <?php echo e($generateCode); ?></div>
                <form action="<?php echo e(route("checkOut")); ?>" enctype="multipart/form-data" method="post" class="w-100">
                    <?php echo csrf_field(); ?>
                    <div class="w-50 my-2">
                        <input type="text" name="inputCode" class="rounded">
                    </div>
                    <input style="display: none" name="genCode" value="<?php echo e($generateCode); ?>">
                    <div class="text-danger">
                        <?php $__errorArgs = ['inputCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            Passcode does not match
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class=" w-50 btn btn-primary">Confirm</button>
                </form>
            </div>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/cartCheckOut.blade.php ENDPATH**/ ?>