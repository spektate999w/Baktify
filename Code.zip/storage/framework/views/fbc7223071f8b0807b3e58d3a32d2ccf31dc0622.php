
<?php $__env->startSection('webCon'); ?>
<div>
    <h3 class="text-center fw-semibold my-4">Update Profile</h3>
    <div class="d-flex justify-content-center">
    <form action=<?php echo e(route("updateProfile")); ?> enctype="multipart/form-data" method="post" class="bg-light shadow rounded p-3 w-75 mb-5">
        <?php echo method_field('patch'); ?>
        <?php echo csrf_field(); ?>
        <div class="my-3">
            <div>Name</div>
            <input name="name" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->name); ?>">
            <div class="text-danger">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="my-3">
            <div>Email address</div>
            <input disabled name="mail" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->email); ?>">
            <div class="text-danger">
                <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="d-flex gap-5 my-2">
            <div>
                <div>Password</div>
                <input name="pw" class="border-secondary border rounded" type="password" value="<?php echo e(Auth::user()->password); ?>">
            </div>
            <div>
                <div>Confirm Password</div>
                <input name="confPw" class="border-secondary border rounded" type="password">
            </div>
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['pw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="my-3">
            <div>Address</div>
            <textarea name="adr" class="border-secondary border rounded" name="" id=""><?php echo e(Auth::user()->address); ?></textarea>
            <div class="text-danger">
                <?php $__errorArgs = ['adr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="text-secondary">Please write your actual address where you can receive email</div>
        </div>
        <div class="my-3">
            <div>Phone</div>
            <input name="phn" class="border-secondary border rounded" type="text" value="<?php echo e(Auth::user()->phone); ?>">
            <div class="text-danger">
                <?php $__errorArgs = ['phn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="d-flex justify-content-end gap-3">
            <div>
                <a class="p-1 btn btn-danger" href="/show-profile">Cancel</a>
            </div>
            <div>
                <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Save</button>
            </div>
        </div>
        <input type="text" style="display: none" value=<?php echo e(Auth::user()->id); ?> name="id">
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/updateProfile.blade.php ENDPATH**/ ?>