
<?php $__env->startSection('webCon'); ?>
    <form action="<?php echo e(route("insertProduct")); ?>" enctype="multipart/form-data" method="POST" class="my-5">
        <?php echo csrf_field(); ?>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Image</div>
            <input name="img" class="w-75" type="file">
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Product Name</div>
            <input name="prn" class="w-75" type="text">
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['prn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Description</div>
            <input name="dec" class="w-75" type="text">
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['dec'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Price</div>
            <input name="prc" class="w-75" type="number">
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['prc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="py-3 my-3 d-flex border-bottom border-dark">
            <div class="w-25">Product Quantity</div>
            <input name="prq" class="w-75" type="number">
        </div>
        <div class="text-danger">
            <?php $__errorArgs = ['prq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="d-flex py-3 my-3 border-bottom border-dark">
            <div class="w-25">
                Category Name
            </div>
            <div class="w-75">
                <?php if(count($cat) == 0): ?>
                    <div class="text-danger">Please add the category first!</div>
                <?php else: ?> 
                    <div>
                        <select name="ctg" id="">
                            <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($req->id); ?>"><?php echo e($req->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['ctg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="d-flex gap-3">
            <div>
                <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Insert</button>
            </div>
            <div>
                <a class="p-1 btn btn-danger" href="/product">Cancel</a>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/insertProduct.blade.php ENDPATH**/ ?>