
<?php $__env->startSection('webCon'); ?>
    <div>
        <h3 class="fw-semibold my-3"><?php echo e($temp->name); ?></h3>
        <div class="d-flex justify-content-center my-3">
            <img src="<?php echo e(asset("storage/stockImg"."/".$temp->image)); ?>" class="rounded" style="width: 200px; heigh:200px;">
        </div>

        <form action=<?php echo e(route("updateProduct")); ?> enctype="multipart/form-data" method="post" class="bg-light shadow rounded p-3 w-75 mb-5">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Image</div>
                <input name="img" class="w-75" type="file">
            </div>
            <div class="text-danger">
                <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Description</div>
                <input name="dec" class="w-75" type="text" value="<?php echo e($temp->description); ?>">
            </div>
            <div class="text-danger">
                <?php $__errorArgs = ['dec'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Price</div>
                <input name="prc" class="w-75" type="number" value="<?php echo e($temp->price); ?>">
            </div>
            <div class="text-danger">
                <?php $__errorArgs = ['prc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="py-3 my-3 d-flex border-bottom border-dark">
                <div class="w-25">Product Quantity</div>
                <input name="prq" class="w-75" type="number" value="<?php echo e($temp->stock); ?>">
            </div>
            <div class="text-danger">
                <?php $__errorArgs = ['prq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="d-flex gap-3">
                <div>
                    <button type="submit" class="btn btn-primary p-1 rounded shadow-sm">Update</button>
                </div>
                <div>
                    <a class="p-1 btn btn-danger" href="/product">Cancel</a>
                </div>
            </div>
            <input style="display: none" type="text" name="id" value="<?php echo e($temp->id); ?>">
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\JOK\LabProject\resources\views/updateProduct.blade.php ENDPATH**/ ?>